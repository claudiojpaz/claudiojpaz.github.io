#include <stdio.h>
// u3-tabs.c

int main (void)
{
  printf("Uno\tDos\tTres\n");

  return 0;
}
