#include <stdio.h>

// u3-definicion-tipos-ini.c

int main (void)
{
  int la_respuesta = 42;

  printf("%d", la_respuesta);

  return 0;
}
