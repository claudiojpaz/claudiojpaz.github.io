#include <stdio.h>
// u3-def-sin-ini.c

int main (void)
{
  int a=3, b, c=0;

  printf("%d %d %d\n", a, b, c);

  return 0;
}
