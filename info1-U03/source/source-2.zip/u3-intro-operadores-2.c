#include <stdio.h>
// u3-intro-operadores-2.c

int main (void)
{
  int resultado;

  resultado = 2 + 1;

  printf("%d\n", resultado);

  return 0;
}

