#include <stdio.h>
// u3-intro-operadores-3.c

int main (void)
{
  int resultado;

  resultado = 3 * 2 + 1;

  printf("%d\n", resultado);

  return 0;
}

