#include <stdio.h>

// u3-definicion-tipos.c

int main (void)
{
  int la_respuesta;

  la_respuesta = 42;

  printf("%d", la_respuesta);

  return 0;
}
