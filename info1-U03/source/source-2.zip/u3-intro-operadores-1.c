#include <stdio.h>
// u3-intro-operadores-1.c

int main (void)
{
  printf("%d\n", 2 + 1);

  return 0;
}


