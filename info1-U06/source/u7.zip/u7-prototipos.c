#include <stdio.h>

#include "u7-media-definicion.h"

int main (void) {

  printf("La media entre %d y %d es %.1f\n", 7, 8, media(7,8));

  return 0;
}


