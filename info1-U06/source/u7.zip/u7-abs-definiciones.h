int valor_absoluto (int n);
