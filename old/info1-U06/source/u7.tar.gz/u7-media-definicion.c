float media (int n1, int n2)
{
  int suma;
  float resultado;

  suma = n1 + n2;

  resultado = (float) suma / 2;

  return resultado;
}

