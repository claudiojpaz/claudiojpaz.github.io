int valor_absoluto (int n)
{
  return n<0?-n:n;
}

