#include <stdio.h>

#include "u7-test-extern-definition.h"

int a = 4;

int main (void) {

  imp_x();
  imp_x();
  imp_x();
  imp_x();

  return 0;
}

