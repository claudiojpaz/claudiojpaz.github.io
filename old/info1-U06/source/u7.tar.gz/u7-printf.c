#include <stdio.h>

int main (void) {

  printf("Se imprimieron %d + %d caractéres\n", printf("primero el\n"), printf("Hola\n"));

  return 0;
}


